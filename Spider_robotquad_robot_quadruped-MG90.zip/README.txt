                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2204279
Spider robot(quad robot, quadruped)-MG90 by regishsu is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

If you find my design interesting, you could make a small donation:
http://paypal.me/RegisHsu

some of friends are asking about the MG90 servers, I have made it and share them here.
Enjoy. (For SG90, http://www.thingiverse.com/thing:1009659) 
Print parts list:
tibia-f x 2
tibia-b x 2
coxa-f x 2
coxa-b x 2
femur x 4 
hinge x 8
body-u x 1
body-m x 1
body-d x 1

Please refer to my blog for detail assemble process.
http://regishsu.blogspot.tw/2016/09/fighter-spider-1xx.html
video：
https://youtu.be/KdMkPrhLNeA
Instruction：
https://www.instructables.com/id/DIY-Spider-RobotQuad-robot-Quadruped/