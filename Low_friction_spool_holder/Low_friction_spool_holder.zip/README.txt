                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:235925
Low friction spool holder by sneakypoo is licensed under the Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

A replacement spoolholder for the UM2 (or other printers if you create a different mount) which offers very little resistance when unspooling.  

*Update: Added parts for 608 bearings and associated hardware.*  

https://www.youtube.com/watch?v=O8T6kX7FJbM

# Instructions

In addition to the printed parts you will need:  
- 2x 626 bearings (cheap on Ebay)  
- 1x 6mm threaded rod, 95+mm long (better to cut after assembling to make sure)  
- 3x M6 nuts  
**OR for the "608" parts:**  
- 2x 608 bearings  
- 1x 8mm threaded rod, 95+mm long (better to cut after assembling to make sure)  
- 3x M8 nuts  

Please note that I haven't printed and tested the 608 parts as I don't have the hardware for those at the moment.